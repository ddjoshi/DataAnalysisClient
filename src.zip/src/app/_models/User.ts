export class User{

    fname:string;
    lname:string;
    email:string;
    password:string;

}
export const users:User[]=
[

];